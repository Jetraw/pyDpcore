from ._dpcore import _dpcore_lib, dp_status_as_exception, _adapt_path_to_os
import ctypes


def set_loglevel(level):
    levels = ["NONE", "INFO", "DEBUG"]
    if level.upper() not in levels:
        raise ValueError("Log level has to be one of " + str(levels))

    idx = levels.index(level.upper())
    _dpcore_lib.dpcore_set_loglevel(idx)


@dp_status_as_exception
def set_logfile(path):
    cpath = _adapt_path_to_os(path)
    return _dpcore_lib.dpcore_set_logfile(cpath)


@dp_status_as_exception
def load_parameters(path):
    cpath = _adapt_path_to_os(path)
    return _dpcore_lib.dpcore_load_parameters(cpath)


@dp_status_as_exception
def prepare_image(image, identifier, error_bound=1):
    return _dpcore_lib.dpcore_prepare_image(
        image.ctypes.data_as(ctypes.POINTER(ctypes.c_ushort)),
        image.size,
        bytes(identifier, "UTF-8"),
        error_bound)


@dp_status_as_exception
def embed_meta(image, identifier, error_bound=1):
    return _dpcore_lib.dpcore_embed_meta(
        image.ctypes.data_as(ctypes.POINTER(ctypes.c_ushort)),
        image.size,
        bytes(identifier, "UTF-8"),
        error_bound)
